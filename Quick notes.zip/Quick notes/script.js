const express = require('express');  //require express  module
const app = express();      //create an express application
const path = require ('path');  //require path module
const fs = require('fs');   //require fs module

app.use(express.json());   //use json
app.use(express.urlencoded({ extended:true}));  //use urlencoded
app.use(express.static(path.join(__dirname, 'public')));  //use static  
app.set('view engine' , 'ejs');  //set view engine to ejs


app.get('/' , function(req,res){    //get request
    fs.readdir(`./files`,(err, files)=>{   //read the files in the directory
        res.render("index",{files:files});   //render the index.ejs file
    })
})

app.get('/edit/:filename' ,(req,res) =>{    //get request
    res.render('edit', {filename: req.params.filename});   //render the edit.ejs file
})

app.post('/edit' , function(req,res){    //post request
    fs.rename(`./files/${req.body.previous}`, `./files/${req.body.new}.txt` ,(err)=> {  //rename the file
        res.redirect("/");  //redirect to home page
    })
})


app.get('/file/:filename' , function (req,res){     //get request
    fs.readFile(`./file/${req.params.filename}` , "utf-8" , (err, filedata) =>{   //read the file
        res.render('show' , {filename: req.params.filename, filedata: filedata });  //render the show.ejs file
    })
})



app.post('/create' , function(req,res){    //post request 
    fs.writeFile(`./files/${req.body.title.split(' ').join('')}.txt`, req.body.details ,(err) =>{  //write the file
        res.redirect("/")  //redirect to home page

    });

 })

 app.get('/delete/:filename' ,(req,res)=>{    //get request
     fs.unlink(`./files/${req.params.filename}` ,(err)=>{   //delete the file
         res.redirect("/");   //redirect to home page
     })
 })

app.listen(3000 ,()=>{    //listen to port 3000
    console.log("running");  //print running
})
