# Project Summary

This Node.js project is designed to take quick notes without connecting the database and each created file saved on pc. It includes the following key features:
- Feature 1: ease of creating file wiht necessary field and clean interface     
- Feature 2: one click away to  edit  title 
- Feature 3: easy to delete file after completing task

## Installation

To install the necessary dependencies, run the following command:

express  - npm i express
ejs  - npm i ejs
init  - npm i init
nodemon(for autorun)  - npm nodemon (filename) //npx nodemon(filename)